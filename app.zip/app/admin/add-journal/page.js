'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function AddJournalPage() {
  const router = useRouter();

  // ---------- Authentication check ----------
  // useEffect(() => {
  //   const token = localStorage.getItem('adminToken');
  //   if (!token) {
  //     router.push('/admin/login');
  //   }
  // }, [router]);

  // ---------- Fetch categories from backend ----------
  const [categories, setCategories] = useState([]);
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await fetch('/api/categories');
        if (res.ok) {
          const data = await res.json();
          setCategories(data);
        }
      } catch (error) {
        console.error('Failed to fetch categories', error);
      }
    };
    fetchCategories();
  }, []);

  // ---------- Top section state ----------
  const [pageTitle, setPageTitle] = useState('');
  const [description, setDescription] = useState('');
  const [selectedCategories, setSelectedCategories] = useState([]);

  // ---------- Section 1: Google Scholar Citation Tags ----------
  const [citationTitle, setCitationTitle] = useState('');
  const [citationAuthor, setCitationAuthor] = useState('');
  const [citationPubDate, setCitationPubDate] = useState('');
  const [journalTitle, setJournalTitle] = useState('');
  const [volume, setVolume] = useState('');
  const [issue, setIssue] = useState('');
  const [firstPage, setFirstPage] = useState('');
  const [lastPage, setLastPage] = useState('');
  const [pdfUrl, setPdfUrl] = useState('');
  const [abstractUrl, setAbstractUrl] = useState('');
  const [language, setLanguage] = useState('');

  // ---------- Section 2: Google Scholar Metadata ----------
  const [metaJournalName, setMetaJournalName] = useState('');
  const [metaVolume, setMetaVolume] = useState('');
  const [metaIssue, setMetaIssue] = useState('');
  const [metaFirstPage, setMetaFirstPage] = useState('');
  const [metaLastPage, setMetaLastPage] = useState('');
  const [metaPdfUrl, setMetaPdfUrl] = useState('');

  // ---------- Featured Image ----------
  const [featuredImage, setFeaturedImage] = useState(null);

  // ---------- UI state ----------
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });

  // ---------- Handlers ----------
  const handleImageChange = (e) => {
    setFeaturedImage(e.target.files[0]);
  };

  const handleLogout = () => {
    localStorage.removeItem('adminToken');
    router.push('/admin/login');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage({ type: '', text: '' });

    if (!pageTitle.trim()) {
      setMessage({ type: 'error', text: 'Please enter a page title.' });
      return;
    }

    setIsSubmitting(true);

    try {
      const token = localStorage.getItem('adminToken');

      const postData = {
        title: pageTitle,
        excerpt: description,
        categories: selectedCategories,
        status: 'publish',
        citation_title: citationTitle,
        citation_author: citationAuthor,
        citation_publication_date: citationPubDate,
        journal_title: journalTitle,
        volume: volume,
        issue: issue,
        first_page: firstPage,
        last_page: lastPage,
        pdf_url: pdfUrl,
        abstract_url: abstractUrl,
        language: language,
        meta_journal_name: metaJournalName,
        meta_volume: metaVolume,
        meta_issue: metaIssue,
        meta_first_page: metaFirstPage,
        meta_last_page: metaLastPage,
        meta_pdf_url: metaPdfUrl,
      };

      const response = await fetch('/api/journals', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(postData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to publish journal.');
      }

      setMessage({ type: 'success', text: `Journal "${pageTitle}" published successfully!` });

      // Reset all fields
      setPageTitle('');
      setDescription('');
      setSelectedCategories([]);
      setCitationTitle('');
      setCitationAuthor('');
      setCitationPubDate('');
      setJournalTitle('');
      setVolume('');
      setIssue('');
      setFirstPage('');
      setLastPage('');
      setPdfUrl('');
      setAbstractUrl('');
      setLanguage('');
      setMetaJournalName('');
      setMetaVolume('');
      setMetaIssue('');
      setMetaFirstPage('');
      setMetaLastPage('');
      setMetaPdfUrl('');
      setFeaturedImage(null);
      document.getElementById('imageInput').value = '';

    } catch (error) {
      setMessage({ type: 'error', text: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  // ---------- Render ----------
  return (
    <>
      <Header />
      <section
        className="py-3 text-white"
        style={{ background: 'linear-gradient(to right, #2b1c6b, #b4b3e6)' }}
      >
        <div className="container d-flex justify-content-between align-items-center">
          <h2 className="mb-0">Submit New Journal</h2>
          <button
            onClick={handleLogout}
            className="btn btn-outline-light btn-sm"
          >
            Logout
          </button>
        </div>
      </section>

      <div className="container my-5">
        <div className="row justify-content-center">
          <div className="col-lg-8">
            <div className="card shadow-sm border-0">
              <div className="card-body p-4">
                {message.text && (
                  <div
                    className={`alert ${
                      message.type === 'success' ? 'alert-success' : 'alert-danger'
                    }`}
                    role="alert"
                  >
                    {message.text}
                  </div>
                )}

                <form onSubmit={handleSubmit}>
                  {/* TOP SECTION: Page Title, Description, Categories */}
                  <div className="bg-light p-4 rounded-3 mb-4">
                    <h5 className="fw-bold mb-3" style={{ color: '#2b1c6b' }}>
                      📄 Page Information
                    </h5>
                    <div className="row">
                      <div className="col-12 mb-3">
                        <label htmlFor="pageTitle" className="form-label fw-semibold">
                          Page Title *
                        </label>
                        <input
                          type="text"
                          className="form-control"
                          id="pageTitle"
                          value={pageTitle}
                          onChange={(e) => setPageTitle(e.target.value)}
                          placeholder="Enter page title"
                          required
                        />
                      </div>

                      <div className="col-12 mb-3">
                        <label htmlFor="description" className="form-label fw-semibold">
                          Description (Excerpt)
                        </label>
                        <textarea
                          className="form-control"
                          id="description"
                          rows="3"
                          value={description}
                          onChange={(e) => setDescription(e.target.value)}
                          placeholder="Brief description of the journal"
                        />
                      </div>

                      <div className="col-12 mb-3">
                        <label htmlFor="categories" className="form-label fw-semibold">
                          Categories
                        </label>
                        <select
                          multiple
                          className="form-control"
                          id="categories"
                          value={selectedCategories}
                          onChange={(e) =>
                            setSelectedCategories(
                              Array.from(e.target.selectedOptions, (option) =>
                                Number(option.value)
                              )
                            )
                          }
                        >
                          {categories.map((cat) => (
                            <option key={cat.term_id} value={cat.term_taxonomy_id}>
                              {cat.name}
                            </option>
                          ))}
                        </select>
                        <div className="form-text">Hold Ctrl/Cmd to select multiple</div>
                      </div>
                    </div>
                  </div>

                  {/* SECTION 1: Google Scholar Citation Tags */}
                  <div className="bg-light p-4 rounded-3 mb-4">
                    <h5 className="fw-bold mb-3" style={{ color: '#2b1c6b' }}>
                      📚 Google Scholar Citation Tags
                    </h5>
                    <div className="row">
                      <div className="col-md-6 mb-3">
                        <label htmlFor="citationTitle" className="form-label fw-semibold">
                          Citation Title
                        </label>
                        <input
                          type="text"
                          className="form-control"
                          id="citationTitle"
                          value={citationTitle}
                          onChange={(e) => setCitationTitle(e.target.value)}
                          placeholder="Article title"
                        />
                      </div>

                      <div className="col-md-6 mb-3">
                        <label htmlFor="citationAuthor" className="form-label fw-semibold">
                          Citation Author(s)
                        </label>
                        <input
                          type="text"
                          className="form-control"
                          id="citationAuthor"
                          value={citationAuthor}
                          onChange={(e) => setCitationAuthor(e.target.value)}
                          placeholder="e.g. John Doe, Jane Smith"
                        />
                      </div>

                      <div className="col-md-6 mb-3">
                        <label htmlFor="citationPubDate" className="form-label fw-semibold">
                          Citation Publication Date
                        </label>
                        <input
                          type="date"
                          className="form-control"
                          id="citationPubDate"
                          value={citationPubDate}
                          onChange={(e) => setCitationPubDate(e.target.value)}
                        />
                      </div>

                      <div className="col-md-6 mb-3">
                        <label htmlFor="journalTitle" className="form-label fw-semibold">
                          Journal Title
                        </label>
                        <input
                          type="text"
                          className="form-control"
                          id="journalTitle"
                          value={journalTitle}
                          onChange={(e) => setJournalTitle(e.target.value)}
                          placeholder="Journal name"
                        />
                      </div>

                      <div className="col-md-4 mb-3">
                        <label htmlFor="volume" className="form-label fw-semibold">
                          Volume
                        </label>
                        <input
                          type="text"
                          className="form-control"
                          id="volume"
                          value={volume}
                          onChange={(e) => setVolume(e.target.value)}
                          placeholder="e.g. 12"
                        />
                      </div>

                      <div className="col-md-4 mb-3">
                        <label htmlFor="issue" className="form-label fw-semibold">
                          Issue
                        </label>
                        <input
                          type="text"
                          className="form-control"
                          id="issue"
                          value={issue}
                          onChange={(e) => setIssue(e.target.value)}
                          placeholder="e.g. 3"
                        />
                      </div>

                      <div className="col-md-4 mb-3">
                        <label htmlFor="firstPage" className="form-label fw-semibold">
                          First Page
                        </label>
                        <input
                          type="text"
                          className="form-control"
                          id="firstPage"
                          value={firstPage}
                          onChange={(e) => setFirstPage(e.target.value)}
                          placeholder="e.g. 45"
                        />
                      </div>

                      <div className="col-md-6 mb-3">
                        <label htmlFor="lastPage" className="form-label fw-semibold">
                          Last Page
                        </label>
                        <input
                          type="text"
                          className="form-control"
                          id="lastPage"
                          value={lastPage}
                          onChange={(e) => setLastPage(e.target.value)}
                          placeholder="e.g. 67"
                        />
                      </div>

                      <div className="col-md-6 mb-3">
                        <label htmlFor="pdfUrl" className="form-label fw-semibold">
                          PDF URL
                        </label>
                        <input
                          type="url"
                          className="form-control"
                          id="pdfUrl"
                          value={pdfUrl}
                          onChange={(e) => setPdfUrl(e.target.value)}
                          placeholder="https://..."
                        />
                      </div>

                      <div className="col-md-6 mb-3">
                        <label htmlFor="abstractUrl" className="form-label fw-semibold">
                          Abstract URL
                        </label>
                        <input
                          type="url"
                          className="form-control"
                          id="abstractUrl"
                          value={abstractUrl}
                          onChange={(e) => setAbstractUrl(e.target.value)}
                          placeholder="https://..."
                        />
                      </div>

                      <div className="col-md-6 mb-3">
                        <label htmlFor="language" className="form-label fw-semibold">
                          Language
                        </label>
                        <input
                          type="text"
                          className="form-control"
                          id="language"
                          value={language}
                          onChange={(e) => setLanguage(e.target.value)}
                          placeholder="e.g. English"
                        />
                      </div>
                    </div>
                  </div>

                  {/* SECTION 2: Google Scholar Metadata */}
                  <div className="bg-light p-4 rounded-3 mb-4">
                    <h5 className="fw-bold mb-3" style={{ color: '#2b1c6b' }}>
                      🔍 Google Scholar Metadata
                    </h5>
                    <div className="row">
                      <div className="col-md-6 mb-3">
                        <label htmlFor="metaJournalName" className="form-label fw-semibold">
                          Journal Name
                        </label>
                        <input
                          type="text"
                          className="form-control"
                          id="metaJournalName"
                          value={metaJournalName}
                          onChange={(e) => setMetaJournalName(e.target.value)}
                          placeholder="Journal name (metadata)"
                        />
                      </div>

                      <div className="col-md-6 mb-3">
                        <label htmlFor="metaVolume" className="form-label fw-semibold">
                          Volume
                        </label>
                        <input
                          type="text"
                          className="form-control"
                          id="metaVolume"
                          value={metaVolume}
                          onChange={(e) => setMetaVolume(e.target.value)}
                          placeholder="e.g. 12"
                        />
                      </div>

                      <div className="col-md-6 mb-3">
                        <label htmlFor="metaIssue" className="form-label fw-semibold">
                          Issue
                        </label>
                        <input
                          type="text"
                          className="form-control"
                          id="metaIssue"
                          value={metaIssue}
                          onChange={(e) => setMetaIssue(e.target.value)}
                          placeholder="e.g. 3"
                        />
                      </div>

                      <div className="col-md-6 mb-3">
                        <label htmlFor="metaFirstPage" className="form-label fw-semibold">
                          First Page
                        </label>
                        <input
                          type="text"
                          className="form-control"
                          id="metaFirstPage"
                          value={metaFirstPage}
                          onChange={(e) => setMetaFirstPage(e.target.value)}
                          placeholder="e.g. 45"
                        />
                      </div>

                      <div className="col-md-6 mb-3">
                        <label htmlFor="metaLastPage" className="form-label fw-semibold">
                          Last Page
                        </label>
                        <input
                          type="text"
                          className="form-control"
                          id="metaLastPage"
                          value={metaLastPage}
                          onChange={(e) => setMetaLastPage(e.target.value)}
                          placeholder="e.g. 67"
                        />
                      </div>

                      <div className="col-md-6 mb-3">
                        <label htmlFor="metaPdfUrl" className="form-label fw-semibold">
                          PDF URL
                        </label>
                        <input
                          type="url"
                          className="form-control"
                          id="metaPdfUrl"
                          value={metaPdfUrl}
                          onChange={(e) => setMetaPdfUrl(e.target.value)}
                          placeholder="https://..."
                        />
                      </div>
                    </div>
                  </div>

                  {/* Featured Image */}
                  <div className="mb-4">
                    <label htmlFor="imageInput" className="form-label fw-semibold">
                      Featured Image
                    </label>
                    <input
                      type="file"
                      className="form-control"
                      id="imageInput"
                      accept="image/*"
                      onChange={handleImageChange}
                    />
                    <div className="form-text">Optional – shown in the journal list.</div>
                  </div>

                  <button
                    type="submit"
                    className="btn btn-primary w-100 py-2"
                    disabled={isSubmitting}
                    style={{
                      background: 'linear-gradient(to right, #2b1c6b, #b4b3e6)',
                      border: 'none',
                    }}
                  >
                    {isSubmitting ? (
                      <span className="spinner-border spinner-border-sm me-2" role="status" />
                    ) : null}
                    {isSubmitting ? 'Publishing...' : 'Publish Journal'}
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}