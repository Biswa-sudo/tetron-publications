<?php
// index.php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Adjust for production
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once __DIR__ . '/config.php';

// Parse the request path
$path = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '/';
$method = $_SERVER['REQUEST_METHOD'];

// Simple routing
switch ($path) {
    case '/journals':
        if ($method === 'GET') {
            require __DIR__ . '/routes/journals.php';
            getJournals($pdo);
        } elseif ($method === 'POST') {
            require __DIR__ . '/routes/journals.php';
            createJournal($pdo);
        } else {
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
        }
        break;

    case '/auth/login':
        if ($method === 'POST') {
            require __DIR__ . '/routes/auth.php';
            login($pdo);
        } else {
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
        }
        break;
        case '/categories':
    if ($method === 'GET') {
        require_once __DIR__ . '/routes/categories.php';
        getCategories($pdo);
    } else {
        http_response_code(405);
        echo json_encode(['error' => 'Method not allowed']);
    }
    break;

    default:
        http_response_code(404);
        echo json_encode(['error' => 'Not found']);
}
?>