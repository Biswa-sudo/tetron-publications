<?php
// api/routes/categories.php

function getCategories($pdo) {
    $stmt = $pdo->prepare("
        SELECT t.term_id, t.name, t.slug, tt.term_taxonomy_id
        FROM wp_terms t
        JOIN wp_term_taxonomy tt ON t.term_id = tt.term_id
        WHERE tt.taxonomy = 'category'
        ORDER BY t.name ASC
    ");
    $stmt->execute();
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($categories);
}
?>