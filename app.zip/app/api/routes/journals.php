<?php
function getJournals($pdo) {
    // 1. Fetch published posts of type 'post' (or custom type)
    $stmt = $pdo->prepare("
        SELECT ID, post_title, post_name, post_date
        FROM wp_posts
        WHERE post_type = 'post' AND post_status = 'publish'
        ORDER BY post_date DESC
    ");
    $stmt->execute();
    $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $journals = [];
    foreach ($posts as $post) {
        // 2. Fetch all meta fields for this post
        $metaStmt = $pdo->prepare("
            SELECT meta_key, meta_value
            FROM wp_postmeta
            WHERE post_id = ?
        ");
        $metaStmt->execute([$post['ID']]);
        $metas = $metaStmt->fetchAll(PDO::FETCH_KEY_PAIR); // key => value

        // 3. Build the journal object
        $journals[] = [
            'id' => $post['ID'],
            'title' => $post['post_title'],
            'slug' => $post['post_name'],
            'date' => $post['post_date'],
            // meta fields (use your actual meta keys)
            'volume' => $metas['volume'] ?? '',
            'issue' => $metas['issue'] ?? '',
            'first_page' => $metas['first_page'] ?? '',
            'last_page' => $metas['last_page'] ?? '',
            'pdf_url' => $metas['pdf_url'] ?? '',
            'abstract_url' => $metas['abstract_url'] ?? '',
            'language' => $metas['language'] ?? '',
            'citation_title' => $metas['citation_title'] ?? '',
            'citation_author' => $metas['citation_author'] ?? '',
            'citation_publication_date' => $metas['citation_publication_date'] ?? '',
            'journal_title' => $metas['journal_title'] ?? '',
            // Featured image: you can fetch from wp_postmeta where meta_key = '_thumbnail_id'
            'featuredImage' => getFeaturedImage($pdo, $post['ID']),
        ];
    }

    echo json_encode($journals);
}

function getFeaturedImage($pdo, $postId) {
    // Get thumbnail ID
    $stmt = $pdo->prepare("SELECT meta_value FROM wp_postmeta WHERE post_id = ? AND meta_key = '_thumbnail_id'");
    $stmt->execute([$postId]);
    $thumbId = $stmt->fetchColumn();
    if (!$thumbId) return null;

    // Get the attachment URL
    $stmt = $pdo->prepare("SELECT meta_value FROM wp_postmeta WHERE post_id = ? AND meta_key = '_wp_attached_file'");
    $stmt->execute([$thumbId]);
    $file = $stmt->fetchColumn();
    if ($file) {
        // You might need the full URL; adjust based on your uploads folder
        return 'https://your-site.com/wp-content/uploads/' . $file;
    }
    return null;
}
function createJournal($pdo) {
    // 1. Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid JSON']);
        return;
    }

    // 2. Validate required fields
    $title = trim($input['title'] ?? '');
    if (!$title) {
        http_response_code(400);
        echo json_encode(['error' => 'Title is required']);
        return;
    }

    // 3. Insert into wp_posts
    $now = date('Y-m-d H:i:s');
    $stmt = $pdo->prepare("
        INSERT INTO wp_posts 
        (post_title, post_status, post_type, post_date, post_modified, post_name)
        VALUES (?, 'publish', 'post', ?, ?, ?)
    ");
    $slug = sanitize_title($title);
    $stmt->execute([$title, $now, $now, $slug]);
    $postId = $pdo->lastInsertId();

    // 4. Insert meta fields
    $metaFields = [
        'volume' => $input['volume'] ?? '',
        'issue' => $input['issue'] ?? '',
        'first_page' => $input['first_page'] ?? '',
        'last_page' => $input['last_page'] ?? '',
        'pdf_url' => $input['pdf_url'] ?? '',
        'abstract_url' => $input['abstract_url'] ?? '',
        'language' => $input['language'] ?? '',
        'citation_title' => $input['citation_title'] ?? '',
        'citation_author' => $input['citation_author'] ?? '',
        'citation_publication_date' => $input['citation_publication_date'] ?? '',
        'journal_title' => $input['journal_title'] ?? '',
        // Section 2 fields
        'meta_journal_name' => $input['meta_journal_name'] ?? '',
        'meta_volume' => $input['meta_volume'] ?? '',
        'meta_issue' => $input['meta_issue'] ?? '',
        'meta_first_page' => $input['meta_first_page'] ?? '',
        'meta_last_page' => $input['meta_last_page'] ?? '',
        'meta_pdf_url' => $input['meta_pdf_url'] ?? '',
    ];

    $metaStmt = $pdo->prepare("INSERT INTO wp_postmeta (post_id, meta_key, meta_value) VALUES (?, ?, ?)");
    foreach ($metaFields as $key => $value) {
        if ($value !== '') {
            $metaStmt->execute([$postId, $key, $value]);
        }
    }

    // 5. Return success
    echo json_encode(['success' => true, 'id' => $postId]);
}

// Helper: generate slug
function sanitize_title($title) {
    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
    return $slug;
}
?>